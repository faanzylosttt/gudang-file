# charlotte-base (simple basebot)

1. support buttonsMessage and interactiveMessage on WhatsApp business and original WhatsApp  
2. reactsw automatically and can be true or false  
3. light and online 24 hours non-stop  
4. still using node18  
5. support cases and plugins  
6. there is no 100% encryption  
7. simple code,  

**Perhatian, dan perlu dibaca:**
1. Skrip ini tidak mengandung malware, backdoor, atau hal-hal yang merugikan penggunanya.
2. Open source, Anda dilarang menjualnya,
