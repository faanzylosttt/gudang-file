module.exports = {
  BOT_TOKEN: "Bot_Token_Lu",
};